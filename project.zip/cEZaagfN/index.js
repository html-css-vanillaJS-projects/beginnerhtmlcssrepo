const imgcontainer = document.getElementById("container");
count =  3;
//imgcontainer[2].attributes.
function onPress(e){
  2
console.log(imgcontainer.childNodes[2].
}